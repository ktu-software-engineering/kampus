import { useEffect } from "react";
import {
  Clock,
  Share2,
  Bookmark,
  User,
  Settings,
  Mail,
  X,
  ChevronRight,
} from "lucide-react";
import { Button } from "./ui/button";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const menuItems = [
  { icon: Clock, label: "Geçmiş", description: "Son görüntüledikleriniz" },
  { icon: Share2, label: "Paylaşılanlar", description: "Paylaştığınız değerlendirmeler" },
  { icon: Bookmark, label: "Kaydedilenler", description: "Favori üniversiteleriniz" },
  { icon: User, label: "Hesap", description: "Profil bilgileriniz" },
  { icon: Settings, label: "Ayarlar", description: "Uygulama ayarları" },
  { icon: Mail, label: "İletişim", description: "Bize ulaşın" },
];

// Soldan açılan menü paneli ve arkayı karartan örtü
export function Sidebar({ isOpen, onClose }: SidebarProps) {
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  return (
    <>
      <div
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,0.25)",
          zIndex: 40,
          opacity: isOpen ? 1 : 0,
          pointerEvents: isOpen ? "auto" : "none",
          transition: "opacity 0.3s ease",
          backdropFilter: "blur(2px)",
        }}
      />

      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          height: "100%",
          width: "280px",
          background: "#FFFFFF",
          zIndex: 50,
          transform: isOpen ? "translateX(0)" : "translateX(-100%)",
          transition: "transform 0.35s cubic-bezier(0.4, 0, 0.2, 1)",
          display: "flex",
          flexDirection: "column",
          boxShadow: "4px 0 24px rgba(0,0,0,0.08)",
          borderRadius: "0 20px 20px 0",
        }}
      >
        <div
          style={{
            padding: "24px 20px 20px",
            borderBottom: "1px solid rgba(0,99,146,0.1)",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          <div>
            <p style={{ fontSize: "11px", color: "#757575", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: "2px" }}>
              Menü
            </p>
            <p style={{ fontSize: "15px", color: "#006392", fontWeight: 600 }}>
              KampusKarne
            </p>
          </div>
          <Button
            variant="kk-sidebar-close"
            size="unsized"
            onClick={onClose}
            aria-label="Menüyü kapat"
          >
            <X size={16} />
          </Button>
        </div>

        <nav style={{ flex: 1, padding: "12px 0", overflowY: "auto" }}>
          {menuItems.map(({ icon: Icon, label, description }) => (
            <Button
              key={label}
              variant="kk-sidebar-item"
              size="unsized"
            >
              <div
                style={{
                  width: "38px",
                  height: "38px",
                  borderRadius: "12px",
                  background: "rgba(0,99,146,0.08)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  flexShrink: 0,
                }}
              >
                <Icon size={18} color="#006392" />
              </div>
              <div style={{ flex: 1 }}>
                <p style={{ fontSize: "14px", fontWeight: 600, color: "#1a1a2e", margin: 0 }}>
                  {label}
                </p>
                <p style={{ fontSize: "11px", color: "#757575", margin: 0 }}>
                  {description}
                </p>
              </div>
              <ChevronRight size={14} color="#c0c0c0" />
            </Button>
          ))}
        </nav>

        <div style={{ padding: "16px 20px", borderTop: "1px solid rgba(0,99,146,0.1)" }}>
          <p style={{ fontSize: "11px", color: "#b0b0b0", textAlign: "center" }}>
            KampusKarne © 2026 · Üniversite Değerlendirme Platformu
          </p>
        </div>
      </div>
    </>
  );
}