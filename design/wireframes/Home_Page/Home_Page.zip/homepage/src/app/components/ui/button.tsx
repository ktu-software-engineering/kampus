import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "./utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-all disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 shrink-0 [&_svg]:shrink-0 outline-none focus-visible:ring-2 focus-visible:ring-[#006392]/50",
  {
    variants: {
      variant: {
        default:
          "rounded-md bg-primary text-primary-foreground hover:bg-primary/90",
        destructive:
          "rounded-md bg-destructive text-white hover:bg-destructive/90",
        outline:
          "rounded-md border bg-background text-foreground hover:bg-accent hover:text-accent-foreground",
        secondary:
          "rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "rounded-md hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",

        "kk-hamburger":
          "w-10 h-10 p-0 rounded-xl cursor-pointer " +
          "bg-transparent border-none shadow-none " +
          "hover:bg-[rgba(0,99,146,0.06)] " +
          "transition-all duration-200",

        "kk-nav":
          "rounded-full px-3.5 py-2 cursor-pointer bg-transparent border-none " +
          "text-[#06283a] text-sm font-medium " +
          "hover:bg-[rgba(0,99,146,0.08)] hover:text-[#006392] " +
          "transition-all duration-200",

        "kk-login":
          "rounded-[8px] px-5 py-2.5 ml-1 cursor-pointer " +
          "bg-[#06283a] border-none text-[#F6F1E7] " +
          "text-sm font-semibold tracking-[0.01em] " +
          "hover:bg-[#006392] hover:-translate-y-px " +
          "transition-all duration-200",

        "kk-search-submit":
          "rounded-full h-[46px] px-5 shrink-0 cursor-pointer " +
          "bg-[#06283a] border-none text-[#F6F1E7] " +
          "text-sm font-semibold tracking-[0.01em] " +
          "hover:bg-[#006392] transition-all duration-200",

        "kk-tag":
          "rounded-full px-3 py-1 cursor-pointer border " +
          "bg-[rgba(255,253,248,0.55)] border-[rgba(255,255,255,0.7)] " +
          "text-xs font-medium text-[#06283a] " +
          "hover:bg-[#06283a] hover:text-[#F6F1E7] hover:border-[#06283a] " +
          "transition-all duration-200",

        "kk-cat":
          "group flex-col gap-0 w-full cursor-pointer rounded-[22px] pt-[20px] pb-[18px] px-4 " +
          "bg-[rgba(255,253,248,0.46)] border-[1.5px] border-[rgba(255,255,255,0.72)] " +
          "shadow-[0_4px_16px_-6px_rgba(6,40,58,0.08)] " +
          "hover:bg-[rgba(255,253,248,0.88)] hover:border-[rgba(0,99,146,0.25)] " +
          "hover:shadow-[0_10px_28px_-8px_rgba(6,40,58,0.18)] " +
          "[&_svg]:!w-auto [&_svg]:!h-auto [&_svg]:!shrink-0 " +
          "relative " +
          "transition-all duration-300",

        "kk-ghost-link":
          "bg-transparent border-none p-0 cursor-pointer " +
          "gap-1.5 text-[13px] font-semibold " +
          "text-[#006392] hover:text-[#06283a] " +
          "transition-all duration-200",

        "kk-cta":
          "rounded-[14px] px-7 py-4 shrink-0 cursor-pointer " +
          "bg-[#F6F1E7] border-none text-[#06283a] " +
          "text-sm font-bold tracking-[0.015em] " +
          "shadow-[0_8px_24px_-8px_rgba(0,0,0,0.35),inset_0_1px_0_rgba(255,255,255,0.6)] " +
          "hover:bg-[#FFFCF3] hover:-translate-y-0.5 " +
          "hover:shadow-[0_14px_32px_-10px_rgba(0,0,0,0.45),inset_0_1px_0_rgba(255,255,255,0.7)] " +
          "transition-all duration-200",

        "kk-sidebar-close":
          "w-8 h-8 p-0 rounded-full cursor-pointer border-none " +
          "bg-[#FFF3DB] text-[#757575] " +
          "hover:bg-[#ffe9b0] " +
          "transition-colors duration-200",

        "kk-sidebar-item":
          "w-full justify-start rounded-none px-5 py-[14px] cursor-pointer border-none " +
          "bg-transparent text-left gap-[14px] " +
          "hover:bg-[#FFF3DB] " +
          "transition-colors duration-200",

        "kk-feedback-close":
          "w-7 h-7 p-0 rounded-full cursor-pointer border-none " +
          "bg-white/15 text-white " +
          "hover:bg-white/25 " +
          "transition-colors duration-200",

        "kk-feedback-submit":
          "w-full rounded-xl py-[10px] cursor-pointer border-none " +
          "bg-[#006392] text-white text-[13px] font-semibold " +
          "hover:bg-[#005580] " +
          "disabled:bg-[#c0c0c0] disabled:cursor-not-allowed disabled:opacity-100 " +
          "transition-colors duration-200",

        "kk-feedback-trigger":
          "rounded-full px-[18px] py-3 cursor-pointer border-none " +
          "bg-[#006392] text-white text-[13px] font-semibold " +
          "shadow-[0_4px_20px_rgba(0,99,146,0.35)] " +
          "hover:-translate-y-0.5 hover:shadow-[0_8px_28px_rgba(0,99,146,0.4)] " +
          "transition-all duration-200",
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        sm: "h-8 rounded-md gap-1.5 px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9 rounded-md",
        unsized: "",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

const Button = React.forwardRef<
  HTMLButtonElement,
  React.ComponentProps<"button"> &
    VariantProps<typeof buttonVariants> & {
      asChild?: boolean;
    }
>(({ className, variant, size, asChild = false, ...props }, ref) => {
  const Comp = asChild ? Slot : "button";

  return (
    <Comp
      ref={ref}
      data-slot="button"
      className={cn(buttonVariants({ variant, size, className }))}
      {...props}
    />
  );
});

Button.displayName = "Button";

export { Button, buttonVariants };