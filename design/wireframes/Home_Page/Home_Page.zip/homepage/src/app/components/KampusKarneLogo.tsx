import logoImg from "../../imports/Gemini_Generated_Image_oq62kmoq62kmoq62.png";
import { useEffect, useState } from "react";

interface KampusKarneLogoProps {
  height?: number;
  light?: boolean;
}

// Logo görselini canvas üzerinde işleyerek arka planı saydamlaştırır
// ve içindeki "5.0" metnini maskeler. CORS hatasında orijinal logoyu
// CSS filtreleriyle gösteren yedek bir akışa düşer.
export function KampusKarneLogo({ height = 40, light = false }: KampusKarneLogoProps) {
  const [dataUrl, setDataUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    const img = new Image();
    img.crossOrigin = "anonymous";

    img.onload = () => {
      try {
        const W = img.width;
        const H = img.height;

        const canvas = document.createElement("canvas");
        canvas.width = W;
        canvas.height = H;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0);

        const imageData = ctx.getImageData(0, 0, W, H);
        const d = imageData.data;

        // Sol üst köşedeki rengi referans alarak benzer pikselleri saydamlaştır
        const bgR = d[0], bgG = d[1], bgB = d[2];
        const TOL = 40;

        for (let i = 0; i < d.length; i += 4) {
          const r = d[i], g = d[i + 1], b = d[i + 2];
          if (
            Math.abs(r - bgR) < TOL &&
            Math.abs(g - bgG) < TOL &&
            Math.abs(b - bgB) < TOL
          ) {
            d[i + 3] = 0;
          }
        }

        // Logo üzerindeki "5.0" yazısını çevre rengiyle örterek görünmez yap
        const sX = Math.floor(W * 0.40);
        const sY = Math.floor(H * 0.38);
        const si = (sY * W + sX) * 4;
        const pR = d[si + 3] > 50 ? d[si]     : 232;
        const pG = d[si + 3] > 50 ? d[si + 1] : 224;
        const pB = d[si + 3] > 50 ? d[si + 2] : 206;

        const x1 = Math.floor(W * 0.545);
        const x2 = Math.floor(W * 0.740);
        const y1 = Math.floor(H * 0.440);
        const y2 = Math.floor(H * 0.610);

        for (let y = y1; y < y2; y++) {
          for (let x = x1; x < x2; x++) {
            const i = (y * W + x) * 4;
            if (d[i + 3] > 30) {
              d[i]     = pR;
              d[i + 1] = pG;
              d[i + 2] = pB;
              d[i + 3] = 255;
            }
          }
        }

        ctx.putImageData(imageData, 0, 0);
        setDataUrl(canvas.toDataURL("image/png"));
      } catch {
        // Cross-origin engeli görseli okumayı engellerse CSS yedek akışına geç
        setFailed(true);
      }
    };

    img.onerror = () => setFailed(true);
    img.src = logoImg;
  }, []);

  // Canvas işlemi tamamlanmadıysa veya başarısız olduysa orijinal görseli
  // mix-blend-mode ile arka plana karışacak biçimde göster
  if (failed || dataUrl === null) {
    return (
      <img
        src={logoImg}
        alt="KampusKarne"
        style={{
          height: `${height}px`,
          width: "auto",
          display: "block",
          mixBlendMode: light ? "screen" : "multiply",
          filter: light
            ? "brightness(0) invert(1)"
            : "hue-rotate(-20deg) saturate(1.2) brightness(1.05)",
        }}
      />
    );
  }

  return (
    <img
      src={dataUrl}
      alt="KampusKarne"
      style={{
        height: `${height}px`,
        width: "auto",
        display: "block",
        filter: light
          ? "brightness(0) invert(1)"
          : "hue-rotate(-20deg) saturate(1.2) brightness(1.05)",
      }}
    />
  );
}
